package solution1;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaPairRDD;	
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;


/*
 * 
 * Year wise get the count of top 4 Airports with the maximum number of outgoing flights, 
 * order the results in descending order w.r.t the number of outgoing flights.
 *
 */

public class Driver1 {
	
	public static void main(String[] args) {
		
		SparkConf conf = new SparkConf().setAppName("C5_session").setMaster("local[2]");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		// Suppress the INFO logs
		sc.setLogLevel("WARN");
		
		// load the data
		JavaRDD<String> rawData = sc.textFile("data/AirLineData.csv");
		
		//filter the data
		// remove the header
		JavaRDD<String> cleanData = rawData.filter(x->x.split(",")[0].startsWith("A"));
		
		// get the required fields 
		// Key - <Year:Origin>
		// Value - 1
		JavaPairRDD<String,Integer> rdd1 = cleanData.mapToPair(x->{
			String[] arr = x.split(",");
			// key - year : origin 
			return new Tuple2<String,Integer>(arr[1].trim()+":"+arr[18].trim(),1);
		});
		
		// Year wise count outgoing flights per airport
		// 2004:ORD, 1
		// 2004:ORD, 4
		// 2004:ORD,10
		
		// Step-01 
		// (1,4) -> 1 + 4 = 5 
		// Step-02
		// (5,10) -> 5+10 = 15

		JavaPairRDD<String,Integer> rdd2 = rdd1.reduceByKey((a,b)->a+b);
		
		// Re-structure 
		// Key - Year
		// Value - Tuple2<Origin, Count>
		JavaPairRDD<String,Tuple2<String,Integer>> rdd3 = rdd2.mapToPair(x->{
			String[] arr = x._1.split(":");
			Tuple2<String,Integer> t2 = new Tuple2<String,Integer>(arr[1],x._2);
			return new Tuple2<String, Tuple2<String,Integer>>(arr[0],t2);
		});
		
		// For each year get the Airport with maximum number of outgoing flight
		JavaPairRDD<String,Tuple2<String,Integer>> rdd4 = rdd3.reduceByKey((a,b)->{
			if(a._2 > b._2) return a;
			return b;
		});
		
		// sort the results 
		//First Re-structure  (2004, (ORD, 1005))-----------> (1005, 2004:ORD)
		JavaPairRDD<Integer,String> rdd5 = rdd4.mapToPair(x->{
			return new Tuple2<Integer,String>(x._2._2, x._1+":"+x._2._1);
		}).sortByKey(false);
				
		// Re-structure 
		// key - Year
		// Value - Tuple2<Origin, Count>
		JavaPairRDD<String,Tuple2<String,Integer>> rdd6 = rdd5.mapToPair(x->{
			String[] arr = x._2.split(":");
			Tuple2<String,Integer> t2 = new Tuple2<String,Integer>(arr[1],x._1);
			return new Tuple2<String,Tuple2<String,Integer>>(arr[0],t2);
		});
		
		// print
		for(Tuple2<String,Tuple2<String,Integer>> val: rdd6.collect()) {
			System.out.println(val._1+" "+val._2._1+" "+val._2._2);
		}
		
		
	}
	
}
