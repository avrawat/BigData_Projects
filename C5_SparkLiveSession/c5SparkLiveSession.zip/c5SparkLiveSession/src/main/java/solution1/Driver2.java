package solution1;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;
import static org.apache.spark.sql.functions.row_number;


/*
 * 
 * Year wise get the count of top 4 Airports with the maximum number of outgoing flights, 
 * order the results in descending order w.r.t the number of outgoing flights.
 *
 */
public class Driver2 {
	public static void main(String[] main) {
		
		SparkSession spark = SparkSession
				  .builder()
				  .appName("C5LiveSesssionDF")
				  .master("local[2]")
				  .getOrCreate();
		
		// Suppress the INFO logs 
		spark.sparkContext().setLogLevel("WARN");
		
		// Load the data
		// Specify that Data file has a header Row
		Dataset<Row> rawData = spark.read()
				.option("header", "true")
				.csv("data/AirLineData.csv");
		
		//rawData.show();
	
		// Count the outgoing flights per year from each airport
		Dataset<Row> df1 = rawData.select("year","origin").groupBy("year","origin").count();
		
		// df1.show();
		// create a window operator
		// To get the Maximum #outgoing flights, the airport Origin each year
		// Partition By Year, order by the count
		WindowSpec w = Window.partitionBy(df1.col("year")).orderBy(df1.col("count").desc());
		
		// Assign row number on each partition as rank
		Dataset<Row> df2 = df1.withColumn("rank", 
				row_number()
				.over(w));
		
		// get the rank = 1 from each partition
		// For each year(partition) the airport with maximum outgoing flights
		df2.select("year","origin","Count")
		.where("rank=1")
		.orderBy(df2.col("Count").desc())
		.show();
		
	}

}
