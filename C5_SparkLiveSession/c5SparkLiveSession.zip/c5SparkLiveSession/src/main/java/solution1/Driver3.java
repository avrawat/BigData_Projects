package solution1;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class Driver3 {
	public static void main(String[] main) {
		SparkSession spark = SparkSession
				  .builder()
				  .appName("C5LiveSesssionDF")
				  .master("local[2]")
				  .getOrCreate();
		// Suppress the INFO logs
		spark.sparkContext().setLogLevel("WARN");
		
		// load the data
		// Specify that Data file has a header Row
		Dataset<Row> rawData = spark.read()
				.option("header", "true")
				.csv("data/AirLineData.csv");
		
		// Create a TEMP view to allow running a SQL query on it
		rawData.createOrReplaceTempView("table1");
		// Count the outgoing flights per year from each airport
		Dataset<Row> df1 = spark.sql("SELECT year, origin, count(Origin) AS count FROM table1 GROUP BY year, origin");
		//df1.show();
		
				
     	// Create a TEMP view to allow running a SQL query on it
		df1.createOrReplaceTempView("table2");
		// create a window operator
		// To get the Maximum #outgoing flights, the airport Origin each year
		// Partition By Year, order by the count
		// Assign row number on each partition as rank
		Dataset<Row> df2 = spark.sql("SELECT year, origin, count, ROW_NUMBER() OVER(PARTITION BY year ORDER BY count DESC) AS rank FROM table2");
		//df2.show();
		
		
		// Create a TEMP view to allow running a SQL query on it
		df2.createOrReplaceTempView("table3");
		// get the rank = 1 from each partition
		// For each year(partition) the airport with maximum outgoing flights
		Dataset<Row> df3 = spark.sql("SELECT year,origin,count FROM table3 WHERE rank = 1 ORDER BY count DESC");
		
		df3.show();
	}

}
