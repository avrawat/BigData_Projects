1. Create a fat jar

2. java -jar cryptoKafkaServer-0.0.1-SNAPSHOT-jar-with-dependencies.jar <ip> <topicName>

3. bin/kafka-console-consumer.sh --bootstarp-server localhost:9092 --topic stockData3 