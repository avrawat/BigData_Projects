package schemaClasses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StockPricePOJO {
	
	@SerializedName("symbol")
	@Expose
	private String symbol;

	@SerializedName("timestamp")
	@Expose
	private String timestamp;
	
	@SerializedName("priceData")
	@Expose
	private Price price;
	
	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public Price getPrice() {
		return price;
	}

	public void setPrice(Price price) {
		this.price = price;
	}
	
}
