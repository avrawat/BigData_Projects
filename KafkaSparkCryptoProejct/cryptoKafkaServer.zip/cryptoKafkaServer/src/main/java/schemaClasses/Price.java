package schemaClasses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Price {
	
	@SerializedName("close")
	@Expose
	private Double close;
	@SerializedName("high")
	@Expose
	private Double high;
	@SerializedName("low")
	@Expose
	private Double low;
	@SerializedName("open")
	@Expose
	private Double open;
	@SerializedName("volume")
	@Expose
	private Double volume;
	
	public Double getClose() {
		return close;
	}

	public void setClose(Double close) {
		this.close = close;
	}

	public Double getHigh() {
		return high;
	}

	public void setHigh(Double high) {
		this.high = high;
	}

	public Double getLow() {
		return low;
	}

	public void setLow(Double low) {
		this.low = low;
	}

	public Double getOpen() {
		return open;
	}

	public void setOpen(Double open) {
		this.open = open;
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}

	public Price(PricePOJO pricePOJO) {
		this.open = pricePOJO.getOpen();
		this.close = pricePOJO.getClose();
		this.high = pricePOJO.getHigh();
		this.low = pricePOJO.getLow();
		this.volume = pricePOJO.getVolumefrom() - pricePOJO.getVolumeto();
	}
	
}
