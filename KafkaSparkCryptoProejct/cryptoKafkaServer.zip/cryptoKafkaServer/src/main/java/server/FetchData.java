package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.*;
import schemaClasses.*;



public class FetchData {
	
	private static final String API_KEY = "e58567b96c292b72de8da34e4f9a6fc123ff82fdadf409de3a6f485103fcb4f8";
	public static String[] currencies = {"BTC", "ETH", "LTC", "XRP"};
	private static final String BASE_URL = "https://min-api.cryptocompare.com/data/histominute?fsym="; 
	private static final String QUERIES = "&tsym=USD&limit=1&api_key=";
	private static ArrayList<String> responseData = new ArrayList<String>();
	
	//ip of the server
	//localhost
	private static String kafka_server;
	
	//"stockData3"
	private static String topicName;
	
	public static void main(String args[]) throws ParseException {
		
		FetchData.kafka_server = args[0];
		FetchData.topicName = args[1];

		KafkaProducerFile kafkaProducerFile = new KafkaProducerFile(kafka_server);
		Gson gson = new Gson();
		Boolean keepFetching = true;
		
		while(keepFetching) {
			responseData.clear();
			fetchPrices();
			int values = 0;
			for(String response: responseData) {
				JsonParser jsonParser = new JsonParser();
				JsonObject jsonObject = (JsonObject) jsonParser.parse(response);
				PricePOJO pricePOJO = gson.fromJson(jsonObject.get("Data").getAsJsonArray().get(0), PricePOJO.class);
				StockPricePOJO stockPricePOJO = new StockPricePOJO();
				stockPricePOJO.setSymbol(currencies[values]);
				stockPricePOJO.setTimestamp(getDate(pricePOJO.getTime().toString()));
				stockPricePOJO.setPrice(new Price(pricePOJO));
				
				System.out.println(gson.toJson(stockPricePOJO));
				
				kafkaProducerFile.sendToTopic(topicName, gson.toJson(stockPricePOJO));
				values += 1;
			}
			try {
				values = 0;
				TimeUnit.MINUTES.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	private static String getDate(String milliseconds) {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("UTC"));

		long milliSeconds= Long.parseLong(milliseconds);
		milliSeconds *= 1000;
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(milliSeconds);
		return formatter.format(calendar.getTime());
	}
	
	
	// returns an array list of 4 element
	// each element is a JSON string
	// corresponding to each stock
	// the order is defined in the currencies array
	private static void fetchPrices() {
		for (String currency: currencies) {
			
			try {
				
				URL url = new URL(BASE_URL + currency + QUERIES + API_KEY);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");
				
				if (conn.getResponseCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
				}
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line+"\n");
                }
                br.close();
				responseData.add(sb.toString());
				conn.disconnect();

		  } catch (MalformedURLException e) {
			  
			  e.printStackTrace();
		
		  } catch (IOException e) {
			  
			  e.printStackTrace();
		
		  }
			
		}
	}
	
}