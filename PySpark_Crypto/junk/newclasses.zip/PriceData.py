class PriceData:
    
    def __init__(self,op,hp,lp,cp):
        self.__open = op
        self.__high = hp
        self.__low = lp
        self.__close = cp
    
    def getOpen(self):
        return self.__open    
    def getClose(self):
        return self.__close    
    def getHigh(self):
        return self.__high    
    def getLow(self):
        return self.__low
    
    def setOpen(self,value):
        self.__open = value    
    def setHigh(self,value):
        self.__high = value    
    def setLow(self,value):
        self.__low = value    
    def setClose(self,value):
        self.__close = value
    
    def __str__(self):
        return "Price[Open-"+str(self.__open)+",High-"+str(self.__high)+",Low-"+str(self.__low)+",Close-"+str(self.__close)+"]"
