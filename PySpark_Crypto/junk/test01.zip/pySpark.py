from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from uuid import uuid1
from datetime import datetime
import json


def main():

	sc = SparkContext("local[2]", "PySparkStreaming_Kafka_Crypto")
	sc.setLogLevel("WARN")
	ssc = StreamingContext(sc,60)

	brokers = "52.55.237.11:9092"
	topic = "stockData"
	groupID = "Rawat_" + str(datetime.now())
	kvs = KafkaUtils.createDirectStream(ssc, [topic],{"metadata.broker.list": brokers})
	lines = kvs.map(lambda x: x[1])

	#lines.pprint()

	rdd1 = lines.map(lambda rawStream:getStockPriceObject(rawStream))

	rdd1.pprint()

	ssc.start()
	ssc.awaitTermination()


def getStockPriceObject(jsonString):
	jsonOb = json.loads(jsonString)
	priceDataOb = PriceData(jsonOb['priceData']['open'],jsonOb['priceData']['high'],jsonOb['priceData']['low'],jsonOb['priceData']['close'])
	stockDataOb = stocksPrice(jsonOb['symbol'],jsonOb['timestamp'],priceDataOb)
	return stockDataOb


class stocksPrice:
    def __init__(self,symbol,timeStamp,priceData):
        self.__symbol = symbol
        self.__timeStamp = timeStamp
        self.__priceData = priceData
        
    def getSymbol(self):
        return self.__symbol
    def getTimeStamp(self):
        return self.__timeStamp
    def getPriceData(self):
        return self.__priceData
    
    def setSymbol(self,value):
        self.__symbol = value
    def setTimeStamp(self,value):
        self.__timeStamp = value
    def setPriceData(self,value):
        self.__priceData = value
    
    def __str__(self):
        return "Symbol-"+self.__symbol+",TimeStamp-"+self.__timeStamp+","+str(self.__priceData)

class PriceData:
    
    def __init__(self,op,hp,lp,cp):
        self.__open = op
        self.__high = hp
        self.__low = lp
        self.__close = cp
    
    def getOpen(self):
        return self.__open    
    def getClose(self):
        return self.__close    
    def getHigh(self):
        return self.__high    
    def getLow(self):
        return self.__low
    
    def setOpen(self,value):
        self.__open = value    
    def setHigh(self,value):
        self.__high = value    
    def setLow(self,value):
        self.__low = value    
    def setClose(self,value):
        self.__close = value
    
    def __str__(self):
        return "Price[Open-"+str(self.__open)+",High-"+str(self.__high)+",Low-"+str(self.__low)+",Close-"+str(self.__close)+"]"



if __name__== "__main__":
	main()


# spark-submit --jars spark-streaming-kafka-0-8_2.11-2.4.4.jar pySpark.py,schemaClasses.py 
